
import React from 'react';
import type { EventOption } from '../types';

interface EventSelectorProps {
    id: string;
    label: string;
    events: EventOption[];
    selectedValue: string | null;
    onChange: (value: string | null) => void;
    fullEventIds: string[];
}

const EventSelector: React.FC<EventSelectorProps> = ({ id, label, events, selectedValue, onChange, fullEventIds }) => {
    return (
        <div>
            <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">
                {label}
            </label>
            <select
                id={id}
                value={selectedValue || ''}
                onChange={(e) => onChange(e.target.value || null)}
                className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md shadow-sm"
            >
                <option value="">-- No event selected --</option>
                {events.map((event) => (
                    <option
                        key={event.id}
                        value={event.id}
                        disabled={fullEventIds.includes(event.id) && event.id !== selectedValue}
                    >
                        {event.name} {fullEventIds.includes(event.id) && event.id !== selectedValue ? '(Full)' : ''}
                    </option>
                ))}
            </select>
        </div>
    );
};

export default EventSelector;
